# Metodologia e decisões de projeto

## Modelo

Grafo não direcionado `G=(V,E)`, com `|V|=25` e `|E|=40`. Cada nó é uma interseção fictícia e cada aresta é uma rua com custo positivo em km e minutos. A visualização `outputs/grafo.png` é o diagrama do grafo.

## Caminho mínimo

O algoritmo A* minimiza `f(n)=g(n)+h(n)` e usa distância euclidiana como limite inferior. Os dados garantem que cada rua custa pelo menos sua distância euclidiana e pelo menos 1 minuto por km; por isso a heurística não superestima os custos simulados. Dijkstra verifica a equivalência do custo ótimo. BFS considera apenas saltos; DFS apenas acessibilidade.

## Agrupamento e múltiplas paradas

K-Means (`k=3`, semente 42) agrupa as coordenadas das entregas. Dentro de cada zona, vizinho mais próximo escolhe iterativamente o pedido ainda não atendido de menor distância na rede; 2-opt refina a ordem das paradas e A* conecta os trechos. O veículo retorna ao depósito. A linha de base segue a ordem de entrada dos pedidos em cada zona. Os agrupamentos são os mesmos em ambas as condições.

## Avaliação

`reducao(%) = 100 * (distancia_base - distancia_otimizada) / distancia_base`. A avaliação soma km e minutos estimados de todos os grupos. Não equivale a economia financeira comprovada. Reproduza com `python -m src.generate_outputs`.

## Restrições e ética

Não utilizar as rotas simuladas para navegação real. Uma implantação exige mapas e tráfego validados, atenção a privacidade de endereços e dados de clientes, segurança viária e transparência das métricas.
