# Vídeo pitch — até 4 minutos

**0:00–0:35 — Problema**

"A Sabor Express enfrenta atrasos e custos extras porque planeja entregas manualmente. Desenvolvemos um protótipo acadêmico para simular rotas mais eficientes."

**0:35–1:15 — Grafo e algoritmos**

"Representamos 25 locais por nós e 40 ruas por arestas ponderadas por distância e tempo. O A* calcula o menor caminho entre dois locais, e comparamos seu resultado ao Dijkstra. BFS e DFS ajudam a demonstrar a diferença entre busca não ponderada e caminho mínimo."

**1:15–1:55 — Clustering**

"O K-Means separa 18 pedidos simulados em três zonas. Para cada zona, uma heurística de vizinho mais próximo com 2-opt decide a ordem de atendimento e o A* encontra os trechos."

**1:55–2:55 — Demonstração**

"Vou executar o dashboard: primeiro, o mapa e as zonas; depois, as rotas por entregador; por último, a comparação entre algoritmos. As métricas são calculadas automaticamente, e podem ser reproduzidas pelos arquivos de saída."

**2:55–3:35 — Resultados e limites**

"Comparamos a distância e o tempo simulados da ordem original dos pedidos com a ordem sugerida. O percentual exato está no dashboard e no arquivo summary.json. A otimização de múltiplas paradas é heurística e não garante o melhor resultado global."

**3:35–3:55 — Conclusão**

"Este projeto demonstra como grafos, buscas heurísticas e aprendizado não supervisionado podem apoiar decisões logísticas. Como próximo passo, integraríamos mapas reais, trânsito e restrições operacionais."

**Dica:** grave a tela do Streamlit e mostre o README e os gráficos; publique o vídeo no YouTube e envie o link solicitado pelo professor.
