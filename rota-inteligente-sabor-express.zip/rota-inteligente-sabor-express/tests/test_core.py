import unittest
import networkx as nx
from src.core import load_data,astar,dijkstra,bfs,dfs,cost,route,cluster_orders
class RoutingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.g,cls.orders=load_data()
    def test_connected(self):self.assertTrue(nx.is_connected(self.g))
    def test_astar_equals_dijkstra(self):
        for a in self.g:
            for b in self.g:
                for w in ('distance_km','time_min'):
                    self.assertAlmostEqual(cost(self.g,astar(self.g,a,b,w),w),cost(self.g,dijkstra(self.g,a,b,w),w))
    def test_routes_visit_and_return(self):
        stops=[o['node'] for o in self.orders[:5]]
        seq,path,dist,t=route(self.g,stops)
        self.assertEqual(seq[0],seq[-1]);self.assertEqual(set(stops).issubset(seq),True)
        self.assertGreater(dist,0);self.assertGreater(t,0)
    def test_clustering(self):
        labels,centers=cluster_orders(self.g,self.orders,3)
        self.assertEqual(len(labels),len(self.orders));self.assertEqual(len(centers),3)
    def test_bfs_dfs(self):
        for fn in (bfs,dfs):
            path=fn(self.g,'N00','N24');self.assertEqual(path[0],'N00');self.assertEqual(path[-1],'N24')
if __name__=='__main__':unittest.main()
